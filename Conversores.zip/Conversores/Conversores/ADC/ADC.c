﻿/*
 * ADC.c
 *
 * Created: 16/10/2026 9:40:34 a. m.
 *  Author: dylan
 */ 
#include "ADC.h"


void ADC_init(){
	//JUSTIFICAMOS A LA DERECHA
	ADMUX &= ~(1<<ADLAR);
	
	//DESHABILITAMOS EL AUTODISPARO
	ADCSRA &= ~(1<<ADATE);
	
	// SELECCIONAMOS EL VREF AVCC;
	ADMUX &= ~(1 << REFS1);
	ADMUX |=  (1 << REFS0);
	
	//DESHABILITAMOS EL CONVERSOR
	ADCSRA &= ~(1<<ADEN);
	
	//AJUSTAMOS EL PREESCALADOR  FOSC/DIV
	ADCSRA = ADCSRA & 0xF8;    //LIMPIAMOS LOS BITS DEL PREESCLASER B2B1B0
	ADCSRA = ADCSRA | _DIV128; //AJUSTAMOS EL DIVISOR
	
	//CONFIGURAMOS TODOS LOS PINES COMO DIGITALES Y ASI EVITAR GASTO ENERGETICO;
	DIDR0 = 0x00;
}



uint16_t ADC_read(uint8_t channel){
	
	//CONFIGURAMOS EL PIN COMO ANALOGICO
	DIDR0 |= (1<<channel);
	
	//SELECCIONAMOS EL CANAL
	ADMUX = (ADMUX & 0xF0) | (channel & 0x0F);
	
	//HABILITAMOS EL CONVERSOR
	ADCSRA |= (1<<ADEN);
	
	//INICIAMOS LA CONVERSION
	ADCSRA |= (1 << ADSC);

	// ESPERAMOS A QUE LA CONVERSION TERMINE
	while( (ADCSRA & (1<<ADSC)) !=0 );
	
	//DESHABILITAMOS EL CONVERSOR
	ADCSRA &= ~(1<<ADEN);
	
	//REGRESAMOS EL VALOR DE LA CONVERSION DE 10 BITS
	return ADC;

}

float ADC_Map(int sensor_conver, float conv_min, float conv_max, float sal_min, float sal_max){
	
	float m;
	
	m = (sal_max-sal_min)/(conv_max-conv_min);
	
	return (m*sensor_conver-m*conv_min+sal_min);
	
}
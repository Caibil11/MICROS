#define F_CPU 20000000UL 
#include <avr/io.h>
#include <util/delay.h>

// Definición de pines de control en el Puerto C
#define PIN_MAS_TIEMPO   PC3
#define PIN_MENOS_TIEMPO PC4

// Función para generar un retardo variable en milisegundos
void delay_ms(uint16_t ms) {
	while (ms--) {
		_delay_ms(1);
	}
}

int main(void) {
	// Configuración de Puertos de Salida (Registro de 16 bits)
	DDRB = 0xFF; // Puerto B completo como salida (Bits 0-7 del registro)
	DDRD = 0xFF; // Puerto D completo como salida (Bits 8-15 del registro)
	
	// Configuración de Puerto C:
	// PC0, PC1, PC2 -> Entradas binarias.
	// PC3, PC4       -> Entradas para botones de tiempo.
	DDRC &= ~((1 << PC0) | (1 << PC1) | (1 << PC2) | (1 << PIN_MAS_TIEMPO) | (1 << PIN_MENOS_TIEMPO));
	
	// Activar resistencias Pull-up internas en los pines de los botones
	PORTC |= (1 << PIN_MAS_TIEMPO) | (1 << PIN_MENOS_TIEMPO);

	uint16_t registro_16 = 0;
	uint16_t tiempo_base = 500; // Tiempo inicial en milisegundos

	while (1) {
		// 1. Leer la entrada binaria de 3 bits (Máscara 0x07 para aislar PC2, PC1, PC0)
		uint8_t entrada_binaria = PINC & 0x07;

		// 2. Control del tiempo (Lógica invertida por usar Pull-up: presionado = 0)
		if (!(PINC & (1 << PIN_MAS_TIEMPO))) {
			if (tiempo_base < 3000) tiempo_base += 50; // Más lento
			_delay_ms(150); // Anti-rebote
		}
		if (!(PINC & (1 << PIN_MENOS_TIEMPO))) {
			if (tiempo_base > 50) tiempo_base -= 50;   // Más rápido
			_delay_ms(150); // Anti-rebote
		}

		// 3. Modos de desplazamiento según la entrada binaria
		switch (entrada_binaria) {
			case 1: // Desplazamiento a la izquierda de un solo bit (Efecto secuencial)
			if (registro_16 == 0) registro_16 = 0x0001;
			registro_16 = (registro_16 << 1);
			if (registro_16 == 0) registro_16 = 0x0001;
			break;

			case 2: // Desplazamiento a la derecha de un solo bit
			if (registro_16 == 0) registro_16 = 0x8000;
			registro_16 = (registro_16 >> 1);
			if (registro_16 == 0) registro_16 = 0x8000;
			break;

			case 3: // Desplazamiento a la izquierda acumulativo (Llenando con 1s)
			registro_16 = (registro_16 << 1) | 0x0001;
			if (registro_16 == 0xFFFF) registro_16 = 0;
			break;

			case 4: // Desplazamiento a la derecha acumulativo (Llenando con 1s)
			registro_16 = (registro_16 >> 1) | 0x8000;
			if (registro_16 == 0xFFFF) registro_16 = 0;
			break;

			case 5: // Rotación circular a la izquierda (Los bits que salen por un extremo entran por el otro)
			if (registro_16 == 0) registro_16 = 0x000F; // Carga un patrón inicial de 4 bits encendidos
			registro_16 = (registro_16 << 1) | (registro_16 >> 15);
			break;

			case 6: // Rotación circular a la derecha
			if (registro_16 == 0) registro_16 = 0xF000;
			registro_16 = (registro_16 >> 1) | (registro_16 << 15);
			break;

			default: // Caso 0 o 7: Reset / Registro apagado
			registro_16 = 0x0000;
			break;
		}

		// 4. Mapeo del registro de 16 bits a los dos puertos físicos de 8 bits
		PORTB = (uint8_t)(registro_16 & 0x00FF);        // Envía los bits 0-7 al Puerto B
		PORTD = (uint8_t)((registro_16 >> 8) & 0x00FF); // Envía los bits 8-15 al Puerto D

		// 5. Retardo configurado por el usuario
		delay_ms(tiempo_base);
	}
}
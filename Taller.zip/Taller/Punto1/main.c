/*
 * Punto1.c
 *
 * Created: 15/10/2026 9:13:23 p. m.
 * Author : Usuario
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	//configuracion del puerto;
	
	DDRD  = 0xFF;   
	PORTD = 0x00;   

	while (1)
	{
		
		//secuencia de encendido; 
		
		PORTD = 0b00000001;		_delay_ms(300);
		PORTD = 0b00000010;		_delay_ms(300);
		PORTD = 0b00000100;		_delay_ms(300);
		PORTD = 0b00001000;		_delay_ms(300);
		PORTD = 0b00010000;		_delay_ms(300);
		PORTD = 0b00100000;		_delay_ms(300);
		PORTD = 0b01000000;		_delay_ms(300);
		PORTD = 0b10000000;		_delay_ms(300);
		PORTD = 0b01000000;		_delay_ms(300);
		PORTD = 0b00100000;		_delay_ms(300);
		PORTD = 0b00010000;		_delay_ms(300);
		PORTD = 0b00001000;		_delay_ms(300);
		PORTD = 0b00000100;		_delay_ms(300);
		PORTD = 0b00000010;		_delay_ms(300);
		PORTD = 0b00000001;		_delay_ms(300);
	}
}
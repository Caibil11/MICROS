#ifndef F_CPU
#define F_CPU 16000000UL
#endif

#include <avr/io.h>
#include <util/delay.h>

// Tabla de siete segmentos para ÁNODO COMÚN (0 = Encendido, 1 = Apagado)
// Índices del 0 al 9, y 0xBF para el guion '-' (error)
const uint8_t g_digitos7Seg[] = {
	0x40, // 0
	0x79, // 1
	0x24, // 2
	0x30, // 3
	0x19, // 4
	0x12, // 5
	0x02, // 6
	0x78, // 7
	0x00, // 8
	0x10, // 9
	0xBF  // - (Error / División por cero)
};

int main(void)
{
	// Todas las variables declaradas estrictamente al inicio de la función
	uint8_t entrada_datos = 0;
	uint8_t numA = 0;
	uint8_t numB = 0;
	uint8_t operacion = 0;
	int16_t resultado = 0;
	uint8_t flag_error = 0;
	uint8_t centenas = 0;
	uint8_t decenas = 0;
	uint8_t unidades = 0;
	int16_t temp_res = 0;
	uint8_t i = 0;

	// Configuración de Puertos
	DDRA = 0x00;   // Entrada: Num A (PA7:PA4) y Num B (PA3:PA0)
	DDRB = 0x00;   // Entrada: Selectores de operación (PB2:PB0)
	DDRC = 0xFF;   // Salida: Segmentos a-g (PC6:PC0)
	DDRD = 0x07;   // Salida: Control de multiplexación (PD2, PD1, PD0)

	PORTB = 0x07;  // Habilita resistencias pull-up en PB2:PB0

	while (1)
	{
		// 1. Leer entradas
		entrada_datos = PINA;
		numA = (entrada_datos >> 4) & 0x0F;
		numB = entrada_datos & 0x0F;
		operacion = (~PINB) & 0x07; // Lógica inversa por Pull-up interno
		flag_error = 0;

		// 2. Procesar la operación seleccionada
		switch (operacion)
		{
			case 0x00: // Suma
			resultado = numA + numB;
			break;
			
			case 0x01: // Resta
			resultado = numA - numB;
			break;
			
			case 0x02: // Multiplicación
			resultado = numA * numB;
			break;
			
			case 0x03: // División
			if (numB != 0)
			{
				resultado = numA / numB;
			}
			else
			{
				flag_error = 1;
			}
			break;
			
			default:
			flag_error = 1;
			break;
		}

		// 3. Descomponer el resultado en dígitos o manejar error
		if (flag_error)
		{
			centenas = 10; // Índice del guion '-'
			decenas  = 10;
			unidades = 10;
		}
		else
		{
			temp_res = resultado;
			if (temp_res < 0)
			{
				temp_res = -temp_res; // Volverlo positivo para extraer dígitos
				centenas = 10;        // Mostrar signo '-' en las centenas
				decenas  = (uint8_t)((temp_res / 10) % 10);
				unidades = (uint8_t)(temp_res % 10);
			}
			else
			{
				centenas = (uint8_t)((temp_res / 100) % 10);
				decenas  = (uint8_t)((temp_res / 10) % 10);
				unidades = (uint8_t)(temp_res % 10);
			}
		}

		// 4. Multiplexación de los displays
		for (i = 0; i < 10; i++)
		{
			// --- Mostrar Unidades ---
			PORTD = 0x01;
			PORTC = g_digitos7Seg[unidades];
			_delay_ms(2);
			PORTC = 0xFF;

			// --- Mostrar Decenas ---
			if (resultado >= 0 && centenas == 0 && decenas == 0 && !flag_error)
			{
				PORTC = 0xFF;
			}
			else
			{
				PORTD = 0x02;
				PORTC = g_digitos7Seg[decenas];
			}
			_delay_ms(2);
			PORTC = 0xFF;

			// --- Mostrar Centenas ---
			if (resultado >= 0 && centenas == 0 && !flag_error)
			{
				PORTC = 0xFF;
			}
			else
			{
				PORTD = 0x04;
				PORTC = g_digitos7Seg[centenas];
			}
			_delay_ms(2);
			PORTC = 0xFF;
		}

	}

}

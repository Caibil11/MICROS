#define F_CPU 20000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	// Configuración de Puertos
	DDRA = 0x00;   // Puerto A como entrada (Nibble alto = Num A, Nibble bajo = Num B)
	DDRB = 0x00;   // Puerto B como entrada (PB2:PB0 para selección de operación)
	DDRC = 0xFF;   // Puerto C como salida (Resultado de 8 bits)

	// Activación de resistencias de Pull-up opcionales para los selectores
	PORTB = 0x07;  // Habilita pull-up en PB0, PB1 y PB2

	uint8_t entrada_datos;
	uint8_t numA, numB;
	uint8_t operacion;
	uint8_t resultado;

	while (1)
	{
		// 1. Leer datos de entrada y separar los nibbles
		entrada_datos = PINA;
		numA = (entrada_datos >> 4) & 0x0F; // Desplaza 4 bits a la derecha y enmascara
		numB = entrada_datos & 0x0F;        // Enmascara los 4 bits bajos
		// 2. Leer los 3 bits de control (invertidos si usas Pull-up activo en bajo)
		// Si usas lógica directa (Pull-down externo), remueve la inversión '~'
		operacion = (~PINB) & 0x07;

		// 3. Procesar la operación seleccionada
		switch (operacion)
		{
			case 0x00: // 000 - Suma
			resultado = numA + numB;
			break;
			
			case 0x01: // 001 - Resta
			resultado = numA - numB;
			break;
			
			case 0x02: // 010 - Multiplicación
			resultado = numA * numB;
			break;
			
			case 0x03: // 011 - División
			if (numB != 0)
			{
				resultado = numA / numB;
			}
			else
			{
				resultado = 0xFF; // Indicador visual de error (División por cero)
			}
			break;
			
			default: // Otras combinaciones no asignadas
			resultado = 0x00;
			break;
		}

		// 4. Mostrar el resultado en el puerto de 8 bits
		PORTC = resultado;

		_delay_ms(50); // Pequeña pausa para estabilizar lecturas

	}

}
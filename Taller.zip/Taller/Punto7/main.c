/*
 * Punto7.c
 *
 * Created: 22/10/2026 7:56:00 p. m.
 * Author : Usuario
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}


/*
 * Punto2.c
 *
 * Created: 15/10/2026 9:18:15 p. m.
 * Author : Usuario
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void)
{
	int8_t i;

	//config del puerto;

	DDRD  = 0xFF;
	PORTD = 0x00;

	while (1)
	{
		// Inicio de secuencia;
		for (i = 0; i <= 7; i++)
		{
			PORTD |= (1 << i);
			PORTD &= ~(1 << i);
		}

		// Regreso desde el bit 6 para no repetir el 7;
		for (i = 6; i >= 0; i--)
		{
			PORTD |= (1 << i);
			_delay_ms(300);
			PORTD &= ~(1 << i);
		}
	}
}


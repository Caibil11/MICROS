/*
 * Punto3.c
 *
 * Created: 15/10/2026 9:43:10 p. m.
 * Author : Usuario
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

// Salidas hacia el puente H;
#define MOTOR_A  PD2     // Activa el giro a la derecha;
#define MOTOR_B  PD3     // Activa el giro a la izquierda;

// Entradas con pull-up;
#define INA      PB0
#define INB      PB1

int main(void)
{
	uint8_t entradas;

	// Salidas: PD2 y PD3;
	DDRD  |=  (1 << MOTOR_A) | (1 << MOTOR_B);
	PORTD &= ~((1 << MOTOR_A) | (1 << MOTOR_B));    // Motor detenido al inicio;

	// Entradas: PB0 y PB1 (pull-up);
	DDRB  &= ~((1 << INA) | (1 << INB));
	PORTB |=  (1 << INA) | (1 << INB);

	while (1)
	{
		// Bit 0 = INA, bit 1 = INB;
		entradas = PINB & ((1 << INA) | (1 << INB));

		switch (entradas)
		{
			case 0b00:  // INA=0, INB=0 -> Frenado;
			PORTD &= ~((1 << MOTOR_A) | (1 << MOTOR_B));
			break;

			case 0b10:  // INA=0, INB=1 -> Motor a la derecha;
			PORTD |=  (1 << MOTOR_A);
			PORTD &= ~(1 << MOTOR_B);
			break;

			case 0b01:  // INA=1, INB=0 -> Motor a la izquierda;
			PORTD &= ~(1 << MOTOR_A);
			PORTD |=  (1 << MOTOR_B);
			break;

			case 0b11:  // INA=1, INB=1 -> Frenado;
			PORTD &= ~((1 << MOTOR_A) | (1 << MOTOR_B));
			break;
		}
	}
}
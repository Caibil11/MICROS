/*
 * Punto5.c
 *
 * Created: 15/10/2026 10:44:16 p. m.
 * Author : Usuario
 */ 

#define F_CPU 20000000UL
#include <avr/io.h>
#include <util/delay.h>

// Secuencias (cada valor se muestra en PORTD)
const uint8_t seq1[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
const uint8_t seq2[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80,
0x40, 0x20, 0x10, 0x08, 0x04, 0x02};
const uint8_t seq3[] = {0xAA, 0x55};
const uint8_t seq4[] = {0x01, 0x03, 0x07, 0x0F, 0x1F, 0x3F, 0x7F, 0xFF};

int main(void)
{
	uint8_t seleccion;
	uint8_t anterior = 0xFF;            // Valor imposible, fuerza el reinicio al arrancar
	uint8_t paso = 0;
	const uint8_t *seq;
	uint8_t largo;

	DDRD  = 0xFF;                       // Puerto D: 8 salidas
	PORTD = 0x00;

	DDRB  &= 0xF0;                      // PB3..PB0 como entradas
	PORTB |= 0x0F;                      // Pull-up en PB3..PB0

	while (1)
	{
		// Con pull-up un interruptor cerrado lee 0, por eso se invierte
		seleccion = ~PINB & 0x0F;

		// Si el usuario cambió la selección, la secuencia reinicia
		if (seleccion != anterior)
		{
			paso = 0;
			anterior = seleccion;
		}

		switch (seleccion)
		{
			case 1:  seq = seq1; largo = sizeof(seq1); break;
			case 2:  seq = seq2; largo = sizeof(seq2); break;
			case 3:  seq = seq3; largo = sizeof(seq3); break;
			case 4:  seq = seq4; largo = sizeof(seq4); break;
			default: seq = 0;    largo = 0;            break;   // Valor no válido
		}

		if (seq == 0)
		{
			PORTD = 0x00;               // Selección inválida: LEDs apagados
		}
		else
		{
			PORTD = seq[paso];
			paso++;
			if (paso >= largo) paso = 0;
		}

		_delay_ms(300);                 // Tiempo entre pasos
	}
}


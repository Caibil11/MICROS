#define F_CPU 20000000UL 
#include <avr/io.h>
#include <util/delay.h>

int main(void) {
	// 1. CONFIGURACIÓN DE PUERTOS
	
	// Configurar PORTA como entrada para los pulsadores (PA0 a PA3)
	DDRA &= ~((1 << DDA0) | (1 << DDA1) | (1 << DDA2) | (1 << DDA3));
	
	// Configurar PORTB como salida para los LEDs (PB0 a PB2)
	DDRB |= (1 << DDB0) | (1 << DDB1) | (1 << DDB2);
	
	// Estado inicial: Todos los LEDs apagados
	PORTB &= ~((1 << PORTB0) | (1 << PORTB1) | (1 << PORTB2));

	while (1) {
		// En AVR AVR, las entradas se leen mediante el registro PINA
		
		// 2. CONDICIÓN PRIORITARIA: Si se presiona P4 (PA3 == 0), se apagan todos los LEDs
		if (!(PINA & (1 << PINA3))) {
			PORTB &= ~((1 << PORTB0) | (1 << PORTB1) | (1 << PORTB2)); // Apaga D1, D2, D3
			_delay_ms(50); // Antirrebote simple
		}
		
		// 3. CONDICIÓN DE CONTROL: Solo permite encender si TODOS los LEDs están apagados (bits 0, 1 y 2 en PORTB son 0)
		else if ((PORTB & ((1 << PORTB0) | (1 << PORTB1) | (1 << PORTB2))) == 0) {
			
			// Si se pulsa P1 (PA0 == 0)
			if (!(PINA & (1 << PINA0))) {
				PORTB |= (1 << PORTB0); // Enciende D1 (PB0)
				_delay_ms(50);
			}
			// Si se pulsa P2 (PA1 == 0)
			else if (!(PINA & (1 << PINA1))) {
				PORTB |= (1 << PORTB1); // Enciende D2 (PB1)
				_delay_ms(50);
			}
			// Si se pulsa P3 (PA2 == 0)
			else if (!(PINA & (1 << PINA2))) {
				PORTB |= (1 << PORTB2); // Enciende D3 (PB2)
				_delay_ms(50);
			}
		}
	}
}

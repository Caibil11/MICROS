/*
 * Punto4.c
 *
 * Created: 15/10/2026 10:11:43 p. m.
 * Author : Usuario
 */ 

#define F_CPU 20000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#define BOTON   PB0     // Entrada con pull-up
#define SALIDA  PB7     // Salida que cambia cada 3 pulsaciones

volatile uint8_t evento = 0;    // Lo activa la interrupción

// Se ejecuta con cualquier cambio de nivel en PB0 (al presionar y al soltar)
ISR(PCINT1_vect)
{
	evento = 1;
}

int main(void)
{
	uint8_t contador = 0;

	// Entrada con pull-up: PB0
	DDRB  &= ~(1 << BOTON);
	PORTB |=  (1 << BOTON);

	// Salida: PB7, inicia en 0
	DDRB  |=  (1 << SALIDA);
	PORTB &= ~(1 << SALIDA);

	// Interrupción por cambio de pin en PB0 (PCINT8)
	PCICR  |= (1 << PCIE1);         // Habilita el grupo PCINT15..8 (puerto B)
	PCMSK1 |= (1 << PCINT8);        // Solo PB0 genera interrupción
	sei();                          // Habilita interrupciones globales

	while (1)
	{
		if (evento)
		{
			_delay_ms(20);                      // Espera a que pasen los rebotes

			if (!(PINB & (1 << BOTON)))         // ¿Sigue presionado? -> pulsación válida
			{
				contador++;

				if (contador >= 3)
				{
					contador = 0;
					PORTB ^= (1 << SALIDA);     // Invierte solo PB7
				}

				while (!(PINB & (1 << BOTON))); // Espera a que lo suelten
				_delay_ms(20);                  // Antirrebote al soltar
			}

			PCIFR |= (1 << PCIF1);              // Borra interrupciones pendientes por rebotes
			evento = 0;
		}
	}
}
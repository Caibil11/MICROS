/*
 * Punto6.c
 *
 * Created: 22/10/2026 7:55:27 p. m.
 * Author : Usuario
 */ 

#define F_CPU 16000000UL
#include <avr/io.h>
#include <util/delay.h>

#define ROJO      0
#define AMARILLO  1
#define VERDE     2

#define T_VERDE_S     20
#define T_AMARILLO_S  3
void esperar_s(uint8_t n)
{
	for (uint8_t i = 0; i < n; i++)
	{
		_delay_ms(1000);
	}
}

void poner_luz(uint8_t via, uint8_t color)
{
	if (via < 2)
	{
		uint8_t desplaz = via * 3;
		PORTB &= ~(0b111 << desplaz);
		PORTB |=  (1 << (desplaz + color));
	}
	else
	{
		PORTD &= ~0b111;
		PORTD |=  (1 << color);
	}
}

int main(void)
{
	DDRB |= 0b00111111;
	DDRD |= 0b00000111;

	for (uint8_t via = 0; via < 3; via++)
	{
		poner_luz(via, ROJO);
	}
	esperar_s(2);

	while (1)
	{
		for (uint8_t via = 0; via < 3; via++)
		{
			poner_luz(via, AMARILLO);
			esperar_s(T_AMARILLO_S);

			poner_luz(via, VERDE);
			esperar_s(T_VERDE_S);

			poner_luz(via, AMARILLO);
			esperar_s(T_AMARILLO_S);

			poner_luz(via, ROJO);
		}
	}
}
#define F_CPU 20000000UL
#include <avr/io.h>
#include <util/delay.h>

// Vector de codificación optimizado para ÁNODO COMÚN con los pines invertidos en Proteus
// Mapeo físico actual: PD0=DP, PD1=g, PD2=f, PD3=e, PD4=d, PD5=c, PD6=b, PD7=a
const uint8_t digitos7SegInvertidos[] = {
	0xFC, // 0 -> (1111 1100)
	0x60, // 1 -> (0110 0000)
	0xDA, // 2 -> (1101 1010)
	0xF2, // 3 -> (1111 0010)
	0x66, // 4 -> (0110 0110)
	0xB6, // 5 -> (1011 0110)
	0xBE, // 6 -> (1011 1110)
	0xE0  // 7 -> (1110 0000)
};

int main(void) {
	// 1. CONFIGURACIÓN DE PUERTOS
	DDRC = 0xFF;         // Todo el PORTC como SALIDAS (Barra de 8 LEDs)
	PORTC = 0x00;        // Estado inicial: LEDs apagados
	
	DDRD = 0xFF;         // Todo el PORTD como SALIDAS (Display 7 Seg)
	
	// Configurar PA0 a PA3 como entradas
	DDRA &= ~((1 << DDA0) | (1 << DDA1) | (1 << DDA2) | (1 << DDA3));
	// Habilitar las resistencias PULL-UP internas del puerto A
	PORTA |= (1 << PORTA0) | (1 << PORTA1) | (1 << PORTA2) | (1 << PORTA3);
	
	uint8_t posicion = 0;
	
	// Mostrar el '0' inicial en el display (Se usa el operador ~ por ser Ánodo Común)
	PORTD = ~digitos7SegInvertidos[posicion];

	while (1) {
		
		// --- BOTÓN SEL+ (PA2): Moverse al bit más significativo (Incrementar) ---
		if (!(PINA & (1 << PINA2))) {
			_delay_ms(20); // Antirrebote mecánico
			if (!(PINA & (1 << PINA2))) {
				if (posicion < 7) {
					posicion++;
					} else {
					posicion = 0; // Carrusel: vuelve a 0
				}
				PORTD = ~digitos7SegInvertidos[posicion]; // Actualiza el display
				while (!(PINA & (1 << PINA2))); // Esperar a que se suelte
			}
		}
		
		// --- BOTÓN SEL- (PA3): Moverse al bit menos significativo (Decrementar) ---
		if (!(PINA & (1 << PINA3))) {
			_delay_ms(20);
			if (!(PINA & (1 << PINA3))) {
				if (posicion > 0) {
					posicion--;
					} else {
					posicion = 7; // Carrusel: salta a 7
				}
				PORTD = ~digitos7SegInvertidos[posicion]; // Actualiza el display
				while (!(PINA & (1 << PINA3))); // Esperar a que se suelte
			}
		}
		
		// --- BOTÓN ENCENDER (PA1): Prende el LED de la posición actual en el PORTC ---
		if (!(PINA & (1 << PINA1))) {
			_delay_ms(20);
			if (!(PINA & (1 << PINA1))) {
				PORTC |= (1 << posicion); // Enciende el bit correspondiente
				while (!(PINA & (1 << PINA1)));
			}
		}
		
		// --- BOTÓN APAGAR (PA0): Apaga el LED de la posición actual en el PORTC ---
		if (!(PINA & (1 << PINA0))) {
			_delay_ms(20);
			if (!(PINA & (1 << PINA0))) {
				PORTC &= ~(1 << posicion); // Apaga el bit correspondiente
				while (!(PINA & (1 << PINA0)));
			}
		}
	}
}
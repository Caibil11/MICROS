#define F_CPU 20000000UL
#include <avr/io.h>
#include <util/delay.h>

int main(void) {
	// 1. CONFIGURACIÓN DE PUERTOS
	DDRA &= ~((1 << DDA0) | (1 << DDA1)); // PA0 y PA1 como Entradas (Pulsadores)
	DDRB |= (1 << DDB0);                  // PB0 como Salida (LED D1)
	
	PORTB &= ~(1 << PORTB0);              // Estado inicial: LED apagado

	while (1) {
		
		// DETECCIÓN DE PULSADOR P1 (PA0)
		if (!(PINA & (1 << PINA0))) {     // Si se presiona P1 (Lectura en 0)
			_delay_ms(20);                // Antirrebote mecánico
			if (!(PINA & (1 << PINA0))) {
				PORTB ^= (1 << PORTB0);   // CONMUTA EL LED (Uso de XOR '^=')
				
				// Esperar a que se SUELTE el pulsador para evitar bucles
				while (!(PINA & (1 << PINA0)));
				_delay_ms(20);            // Antirrebote al soltar
			}
		}
		
		// DETECCIÓN DE PULSADOR P2 (PA1)
		if (!(PINA & (1 << PINA1))) {     // Si se presiona P2 (Lectura en 0)
			_delay_ms(20);                // Antirrebote mecánico
			if (!(PINA & (1 << PINA1))) {
				PORTB ^= (1 << PORTB0);   // CONMUTA EL LED
				
				// Esperar a que se SUELTE el pulsador
				while (!(PINA & (1 << PINA1)));
				_delay_ms(20);            // Antirrebote al soltar
			}
		}
	}
}

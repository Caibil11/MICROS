/**
 * \file
 *
 * \brief ATmega1284P on STK600 board configuration template
 *
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */

#ifndef CONF_BOARD_H
#define CONF_BOARD_H

#endif // CONF_BOARD_H

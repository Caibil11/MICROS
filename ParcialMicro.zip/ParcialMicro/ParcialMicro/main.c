#define F_CPU 20000000
#include <avr/io.h>
#include <util/delay.h>
#include "LCD/LCD_LIB.h"
#include "DS18B20_LIB/DS18B20_LIB.h"

/*
uint8_t tileA[] = { 0x1F, 0x1F, 0x1B, 0x1F, 0x1F, 0x18, 0x18, 0x18 };
uint8_t tileB[] = { 0x1F, 0x1F, 0x1B, 0x1B, 0x1F, 0x1B, 0x1B, 0x1B };
uint8_t tileC[] = { 0x1F, 0x1F, 0x1B, 0x1F, 0x1C, 0x1E, 0x1B, 0x1B };
uint8_t tileD[] = { 0x1F, 0x1F, 0x18, 0x18, 0x18, 0x18, 0x1F, 0x1F };
uint8_t tileE[] = { 0x1B, 0x1B, 0x1B, 0x1F, 0x1F, 0x1B, 0x1B, 0x1B };
uint8_t tileF[] = { 0x1F, 0x1F, 0x18, 0x1F, 0x1F, 0x18, 0x1F, 0x1F }; 
uint8_t tileG[] = { 0x1F, 0x1F, 0x18, 0x1F, 0x1F, 0x03, 0x1F, 0x1F };
uint8_t tileH[] = { 0x00, 0x18, 0x1B, 0x00, 0x11, 0x0E, 0x00, 0x00 };

int main(void)
{
	lcd_init();

	lcd_custom_char(0, tileA);
	lcd_custom_char(1, tileB);
	lcd_custom_char(2, tileC);
	lcd_custom_char(3, tileD);
	lcd_custom_char(4, tileE);
	lcd_custom_char(5, tileF);
	lcd_custom_char(6, tileG);
	lcd_custom_char(7, tileH);

	lcd_set_cursor(1, 2);  lcd_write(1);
	lcd_set_cursor(1, 3);  lcd_write(2);
	lcd_set_cursor(1, 4);  lcd_write(3);
	lcd_set_cursor(1, 5);  lcd_write(4);
	lcd_set_cursor(1, 6);  lcd_write(5);
	lcd_set_cursor(1, 7);  lcd_write(6);
	lcd_set_cursor(1, 8);  lcd_write(5);
	lcd_set_cursor(1, 9);  lcd_write(5);
	lcd_set_cursor(1, 10); lcd_write(5);
	lcd_set_cursor(1, 12); lcd_write(7);
	lcd_set_cursor(1, 13); lcd_puts(" ");
	lcd_set_cursor(1, 14); lcd_write(0);

	while (1)
	{
	}
}*/

float temp;

int main(void)
{
	lcd_init();
	lcd_disable_blink();
	lcd_disable_cursor();
	
	
	ds18b20_init();

	while(1)
	{
		temp = ds18b20_get_temp();
		
		lcd_set_cursor(1,1);
		lcd_printf("Temp: %5.1f", temp);
		
		_delay_ms(50);
	}
}
################################################################################
# Automatically-generated file. Do not edit or delete the file
################################################################################

DS18B20_LIB\DS18B20_LIB.c

LCD\LCD_LIB.c

main.c

